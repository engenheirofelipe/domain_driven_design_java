package br.com.ancora.app.model;


import java.time.LocalDate;

public class VendedorDaLoja extends Usuario {
	
	private int idVendedor;
	
	private String endereco;
	
	private LocalDate dataContratacao;
	
	private Double salario;
	
	

	public VendedorDaLoja(int idVendedor, LocalDate dataContratacao, Double salario) {
		super();
		this.idVendedor = idVendedor;
		this.dataContratacao = dataContratacao;
		this.salario = salario;
	}



	public int getIdVendedor() {
		return idVendedor;
	}

	public void setIdVendedor(int idVendedor) {
		this.idVendedor = idVendedor;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public LocalDate getDataConstrucao() {
		return dataContratacao;
	}

	public void setDataConstrucao(LocalDate dataConstrucao) {
		this.dataContratacao = dataConstrucao;
	}

	public Double getSalario() {
		return salario;
	}

	public void setSalario(Double salario) {
		this.salario = salario;
	}
	
	
	@Override
	public void fazerLogin() {
		
		System.out.println(" O vendedor do id " + idVendedor + " que possui o email " + email  + " fez login no aplicativo");
		
	}

	@Override
	public void criarCadastro() {
		
		System.out.println(" O vendedor de nome " + nome + " que possui o email " + email + " com o telefone : "  + telefone + 
				" com o cpf : " + cpf + " com o endereco : " + endereco + " com a data de contratação : " + dataContratacao + " fez o cadastro no aplicativo");
		
		
	};
	
	public void atualizarInformacoesProduto(Produto produto, String descricao, String novaDescricao) {
		
		produto.setDescricao(descricao);
		produto.setNovaDescricao(novaDescricao);
  
        System.out.println(" O produto estava com as antigas informações : " + descricao + " Está com a nova descrição com as informações : " + produto.getNovaDescricao());
		
	}
	
	public void processarPedido() {
		
		System.out.println(" O vendedor de nome " + nome + " que possui o email " + email +  " processou o pedido");
		
		
	};




}
