package br.com.ancora.app.model;

public class Produto {
	
	private int idProduto;
	
	public String nomeProduto;
	
	public Double preco;
	
	private String marca;
	
	private int quantidade;
	
	public String descricao;
	
	public String novaDescricao;
	
	private String aplicacoes;
	
	

	public Produto(int idProduto, String nomeProduto, Double preco, String marca, int quantidade, String descricao, String novaDescricao,
			String aplicacoes) {
		super();
		this.idProduto = idProduto;
		this.nomeProduto = nomeProduto;
		this.preco = preco;
		this.marca = marca;
		this.quantidade = quantidade;
		this.descricao = descricao;
		this.aplicacoes = aplicacoes;
		this.novaDescricao = novaDescricao;
	}

	public int getIdProduto() {
		return idProduto;
	}

	public void setIdProduto(int idProduto) {
		this.idProduto = idProduto;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public Double getPreco() {
		return preco;
	}

	public void setPreco(Double preco) {
		this.preco = preco;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	public String getNovaDescricao() {
		return novaDescricao;
	}

	public void setNovaDescricao(String novaDescricao) {
		this.novaDescricao = novaDescricao;
	}

	public String getAplicacoes() {
		return aplicacoes;
	}

	public void setAplicacoes(String aplicacoes) {
		this.aplicacoes = aplicacoes;
	}


	
	
	
	

}
