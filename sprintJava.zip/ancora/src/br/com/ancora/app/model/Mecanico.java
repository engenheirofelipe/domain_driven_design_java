package br.com.ancora.app.model;

public class Mecanico extends Usuario {
	
	private int idMecanico;
	
	private String matriculaCadastro;
	
	public String produtoPesquisa;
	
	private String emailMecanicoAtual;
	
	

	public Mecanico(int idMecanico, String matriculaCadastro, String emailMecanicoAtual, String produtoPesquisa) {
		super();
		
		this.idMecanico = idMecanico;
		this.matriculaCadastro = matriculaCadastro;
		this.emailMecanicoAtual = emailMecanicoAtual;
		this.produtoPesquisa = produtoPesquisa;
	}

	public int getIdMecanico() {
		return idMecanico;
	}

	public void setIdMecanico(int idMecanico) {
		this.idMecanico = idMecanico;
	}

	public String getMatriculaCadastro() {
		return matriculaCadastro;
	}

	public void setMatriculaCadastro(String matriculaCadastro) {
		this.matriculaCadastro = matriculaCadastro;
	}
	
	public String getemailMecanicoAtual() {
		return emailMecanicoAtual;
	}

	public void setPerfil(String emailMecanicoAtual) {
		this.emailMecanicoAtual = emailMecanicoAtual;
	}
	
	public String getProdutoPesquisa() {
		return emailMecanicoAtual;
	}

	public void setprodutoPesquisa(String produtoPesquisa) {
		this.produtoPesquisa = produtoPesquisa;
	}
	
	
	
	
	@Override
	public void fazerLogin() {
		
		System.out.println(" O mecânico de nome " + nome + " que possui o email " + email  + " fez login no aplicativo");
		
	}

	@Override
	public void criarCadastro() {
		
		System.out.println(" O mecânico de nome " + nome + " que possui o email " + email + 
				" com o telefone : "  + telefone + " com o cpf : " + cpf + " com o endereco : " + endereco + 
				" com o id: " + idMecanico + " com a matricula " + matriculaCadastro + " fez o cadastro no aplicativo");
		
		
	};
	
	
	
	public void atualizarPerfil() {
	
		System.out.println(" O mecânico de nome " + nome + " de email " + getEmail() + "  atualizou seu email para : " + emailMecanicoAtual);
		
	}
	
	public void fazerPesquisa() {
		
		System.out.println(" O mecânico pesquisou " + produtoPesquisa);
		
	}
	
	public void solicitarCotacaoProduto() {
		
		System.out.println(" O mecânico solicitou a cotação de " + produtoPesquisa);
		
	}
	
	public void comprarProduto() {
		
		System.out.println(" O mecânico comprou " + produtoPesquisa);
		
	}
	
	
	public void adicionarProdutoAoCarrinho() {
			
		System.out.println(" O mecânico adicionou " + produtoPesquisa  + " ao carrinho " );
			
	}

}
