package br.com.fiap.rh.model;

public class Calculadora {
	
	public int somar(int valor1, int valor2) {
		return valor1 + valor2;
	}
	
	public float somar(float valor1, float valor2) {
		return valor1 + valor2;
	}
	
	public double somar(double valor1, double valor2) {
		return valor1 + valor2;
	}
	
	public double somar(double valor1, double valor2, double valor3) {
		return valor1 + valor2;
	}

}
