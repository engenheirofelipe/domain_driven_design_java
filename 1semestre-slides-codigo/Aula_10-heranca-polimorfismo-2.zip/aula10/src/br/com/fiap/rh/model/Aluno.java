package br.com.fiap.rh.model;

public class Aluno extends Pessoa {
	
	private String rm;
	
	public Aluno(String rm) {
		super();
		this.rm = rm;
	}

	public String getRm() {
		
		
		return rm;
	}

	public void setRm(String rm) {
		this.rm = rm;
	}

	public void estudar() {
		System.out.println("Aluno estudando.");
	}
	
	public void imprimirNomePessoa() {
		System.out.println("O nome da pessoa eh: " + nome);
	}
	
	@Override
	public void comer() {
		System.out.println("Aluno comendo");
	}
	
	public void comer(String tipoComida) {
		System.out.println("Aluno comendo " + tipoComida);
	}

	@Override
	public void correr() {
		System.out.println("O aluno está correndo.");
		
	}
}
