package br.com.fiap.rh.model;

public abstract class Pessoa {
	
	protected String nome;
	
	protected String cpf;
	
	protected short idade;
	
	protected int nota;
	
	public void comer()  {
		System.out.println("Pessoa comendo");
	}
	
	public void andar(float distancia) {
		System.out.println("A pessoa andou a distancia " + distancia);
	}
	
	public abstract void correr();
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public short getIdade() {
		return idade;
	}

	public void setIdade(short idade) {
		this.idade = idade;
	}
	
	
}
