package br.com.fiap.rh.teste;

import br.com.fiap.rh.model.Aluno;
import br.com.fiap.rh.model.Calculadora;
import br.com.fiap.rh.model.Pessoa;
import br.com.fiap.rh.model.Professor;


/*
 * Assinatura de método
 * 
 * O método precisa ter o mesmo nome
 * O método precisa ter a mesma quantidade de parâmetros
 * O método precisa ter os mesmos tipos de parâmetros
 * 
 * 
 * Exemplos de métodos:
 * 
 * Método 1 -> public void somar(int valor1, int valor2) {... } - Mesma assinatura de método
 * 
 * Método 2 -> public void somar(int valor3, int valor4) {... } - Mesma assinatura de método
 * 
 * Método 3 -> public int somar(int valor3, int valor4) {... } - Mesma assinatura de método
 * 
 * Método 4 -> private int somar(int valor3, int valor4) {... } - Mesma assinatura de método
 * 
 * Método 5 -> private int somar(int valor3, double valor4) {... } - Não tem a mesma assinatura de método
 * 
 * Método 6 -> private int somar(int valor3) {... } - Não tem a mesma assinatura de método
 * 
 * 
 * 
 * Sobreposição:
 * 	- Precisa ter a mesma assinatura de método
 *  - E estar em classes diferentes numa herança
 *  
 *  
 *  
 *  Sobrecarga de métodos
 *  
 *  - Precisam estarem na mesma classe
 *  - Precisa ter a assinatura do método diferente
 * 
 */


public class Teste {
	
	public static void main(String[] args) {
		
		Aluno aluno = new Aluno("1234");
		aluno.setNome("Evando");
		aluno.imprimirNomePessoa();
		aluno.comer();
		aluno.comer("fruta");
		aluno.estudar();
		aluno.correr();
		
		Professor professor = new Professor();
		professor.comer();
		professor.ensinar();
		professor.correr();
		
		Calculadora calculadora = new Calculadora();
		System.out.println(calculadora.somar(10, 10));
		
	}

}





