package br.com.fiap.rh.model;

public class Professor extends Pessoa {
	
	private String pf;
	
	public String getPf() {
		return pf;
	}

	public void setPf(String pf) {
		this.pf = pf;
	}

	public void ensinar() {
		System.out.println("Professor ensinando.");
	}
	
	@Override
	public void andar(float distancia) {
		System.out.println("O professor andou a distancia " + distancia);
	}

	@Override
	public void correr() {
		System.out.println("O professor esta correndo.");
		
	}
}
