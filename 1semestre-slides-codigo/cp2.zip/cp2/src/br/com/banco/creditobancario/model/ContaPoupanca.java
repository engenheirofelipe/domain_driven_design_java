package br.com.banco.creditobancario.model;

public class ContaPoupanca extends Conta {
	
	private double rendimento;

	public double getRendimento() {
		return rendimento;
	}

	public void setRendimento(double rendimento) {
		this.rendimento = rendimento;
	}

	@Override
	public void sacar(double valor) {
		this.saldo -= valor;
		System.out.println("Efetuado o saque de R$ " + valor);
	}

	@Override
	public void depositar(double valor) {
		this.saldo += valor;
		System.out.println("Efetuado o deposito de R$ " + valor);
		
	}

	@Override
	public void exibirSaldo() {
		System.out.println("O saldo da conta poupança " + this.numeroConta + " agencia " + this.numeroAgencia + " é " + this.saldo);
		
	}

}
