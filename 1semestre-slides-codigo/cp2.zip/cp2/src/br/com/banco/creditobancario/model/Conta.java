package br.com.banco.creditobancario.model;

public abstract class Conta {
	
	protected int numeroAgencia;
	
	protected int numeroConta;
	
	protected double credito;
	
	protected double debito;
	
	protected double saldo;
	
	protected String cliente;
	
	public abstract void sacar(double valor);
	
	public abstract void depositar(double valor);
	
	public abstract void exibirSaldo();
	
	public int getNumeroAgencia() {
		return numeroAgencia;
	}

	public void setNumeroAgencia(int numeroAgencia) {
		this.numeroAgencia = numeroAgencia;
	}

	public int getNumeroConta() {
		return numeroConta;
	}

	public void setNumeroConta(int numeroConta) {
		this.numeroConta = numeroConta;
	}

	public double getCredito() {
		return credito;
	}

	public void setCredito(double credito) {
		this.credito = credito;
	}

	public double getDebito() {
		return debito;
	}

	public void setDebito(double debito) {
		this.debito = debito;
	}

	protected double getSaldo() {
		return saldo;
	}

	protected void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public String getCliente() {
		return cliente;
	}

	public void setCliente(String cliente) {
		this.cliente = cliente;
	}
}
