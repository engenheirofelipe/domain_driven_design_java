package espr;

import java.util.Scanner;

public class Teste {

	public static void main(String[] args) {
		
		System.out.println("Iniciando por aqui...");
		
		Aluno aluno = new Aluno();
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite o nome do aluno: ");
		aluno.nome = entrada.next();
		
		System.out.println("Digite o tamanho do aluno: ");
		aluno.tamanho = entrada.nextFloat();
		
		System.out.println("Digite o cor do aluno: ");
		aluno.cor = entrada.next();
		
		System.out.println("Digite o documento do aluno: ");
		aluno.documento = entrada.next();
		
		aluno.estudar();
		aluno.jogar();
		aluno.conversar();
		aluno.imprimirFormatado();
		
		
		
		Aluno joao = new Aluno();
		
		System.out.println("Digite o nome do aluno: ");
		joao.nome = entrada.next();
		
		System.out.println("Digite o tamanho do aluno: ");
		joao.tamanho = entrada.nextFloat();
		
		System.out.println("Digite o cor do aluno: ");
		joao.cor = entrada.next();
		
		System.out.println("Digite o documento do aluno: ");
		joao.documento = entrada.next();
		
		joao.estudar();
		joao.jogar();
		joao.conversar();
		
		Mesa mesa = joao.construirMesa();
		mesa.cor = "Branca";
		
		entrada.close();
		
		System.out.println("Finalizando");

	}

}
