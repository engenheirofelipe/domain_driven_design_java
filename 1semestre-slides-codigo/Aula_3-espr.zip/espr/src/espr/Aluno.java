package espr;

public class Aluno {
	
	String nome;
	String documento;
	float tamanho;
	String cor;
	
	void estudar() {
		
		System.out.println("O aluno " + nome + " do documento " + documento + " tem o tamanho " + tamanho + " e cor " + cor);
		
	}
	
	void conversar() {
		
		System.out.println("O aluno " + nome + " está conversando");
		
	}
	
	void imprimirFormatado() {
		System.out.printf("O aluno %s do documento %s tem o tamanho %1.4f e cor %s%n", nome, documento, tamanho, cor);
	}
	
	void jogar() {
		
		
		 System.out.println("O aluno " + nome + " está jogando");
	}
	
	Mesa construirMesa() {
		
		Mesa mesa = new Mesa();
		mesa.comprimento=10;
		mesa.largura = 5;
		
		return mesa;
	}

}
