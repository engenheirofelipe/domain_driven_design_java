package espr;

public class Mesa {
	
	String cor;
	String modelo;
	String material;
	float preco;
	int largura;
	int comprimento;
	
	void apoiar() {
		
	}
	
	int calcularArea() {
		return (largura * comprimento);
	}

}
