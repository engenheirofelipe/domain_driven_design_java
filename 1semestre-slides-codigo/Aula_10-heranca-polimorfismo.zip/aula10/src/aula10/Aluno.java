package aula10;

public class Aluno extends Pessoa {
	
	private String rm;
	
	public String getRm() {
		return rm;
	}

	public void setRm(String rm) {
		this.rm = rm;
	}

	public void estudar() {
		System.out.println("Aluno estudando.");
	}
}
