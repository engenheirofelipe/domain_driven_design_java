package operadores;

public class Calculadora {
	
	// somar
	public int somar(int a, int b) {
		int resultado = a + b;
		System.out.println("O resultado da soma e: " + resultado);
		return resultado;
	}
	
	public int somar(int a, int b, int c) {
		int resultado = a + b;
		//resultado += c;
		resultado = resultado + c;
		System.out.println("O resultado da soma e: " + resultado);
		return resultado;
	}
	
	// subtratir
	public int subtrair(int a, int b) {
		int resultado = a - b;
		System.out.println("O resultado da subtracao e: " + resultado);
		return resultado;
	}
	
	public int subtrair(int a, int b, int c) {
		int resultado = a - b;
		resultado -= c;
		System.out.println("O resultado da subtracao e: " + resultado);
		return resultado;
	}
	
	// dividir
	public float dividir(float a, float b) {
		float resultado = a / b;
		System.out.println("O resultado da divisao e: " + resultado);
		return resultado;
	}
	
	public float dividir(float a, float b, float c) {
		float resultado = a / b;
		resultado/= c;
		System.out.println("O resultado da divisao e: " + resultado);
		return resultado;
	}
	
    // multiplicar
	public int multiplicar(int a, int b) {
		int resultado = a * b;
		System.out.println("O resultado da multiplicacao e: " + resultado);
		return resultado;
	}
	
	public int multiplicar(int a, int b, int c) {
		int resultado = a * b;
		resultado *= c;
		System.out.println("O resultado da multiplicacao e: " + resultado);
		return resultado;
	}
	
	public void verificarParOuImpar(int valor) {
		if(valor % 2 == 0) {
			System.out.println("O número e par");
		} else {
			System.out.println("O número e impar");
		}
	}
	
}