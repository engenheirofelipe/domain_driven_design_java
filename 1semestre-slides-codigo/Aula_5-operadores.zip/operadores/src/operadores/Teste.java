package operadores;

public class Teste {

	public static void main(String[] args) {
		
		Calculadora calculadora = new Calculadora();
		calculadora.somar(10, 3);
		calculadora.somar(10, 20, 30);
		calculadora.subtrair(10, 3);
		calculadora.subtrair(10, 5, 5);
		calculadora.dividir(10, 3);
		calculadora.dividir(10, 2, 2);
		calculadora.multiplicar(10, 4);
		calculadora.multiplicar(10, 3, 2);
		calculadora.verificarParOuImpar(10);
		
		int valor1 = 20;
		int valor2 = 20;
		int valor3 = 20;
		
		if(valor1 == valor2) {
			System.out.println("O valor é igual");
		} 
		if(valor1 != valor2) {
			System.out.println("O valor é diferente");
		}
		
		if(valor1==valor2 && valor2== valor3) {
			System.out.println("Todas condicoes verdadeiras");
		}
		
		if(valor1==valor2 || valor2== valor3) {
			System.out.println("Umas das condicoes verdadeira");
		}
		
		if(!(valor1==valor2)) {
			System.out.println("Condicional de negacao");
		}
	}
}
