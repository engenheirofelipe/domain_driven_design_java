package br.com.fiap.rh.teste;

import java.util.Scanner;

public class TesteVetorPrimitivo {
	
	public static void main(String[] args) {
		
		
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite todos os valores do array separados por espaco");
		
		String[] entradas = entrada.nextLine().split(" ");
		
		// Exercício 1 - Somar vetor
		somarVetor(entradas);
		
		// Exercicio 2 - Verificar maior e menor
		verificarMaiorMenor(entradas);
		
		//Exercicio 3 - Calcular média
		calcularMedia(entradas);
		
		// Exercicio 4 - Inverter elementos do vetor
		inverterElementoVetor(entradas);
		
		// Exercicio 5 - Verificar par impar
		verificarParImpar(entradas);
		
		entrada.close();
	}

	private static void somarVetor(String[] entradas) {
		
		System.out.println("###### Soma do vetor ######");
		
		int elementosVetor[] = new int[entradas.length];
		
		int total = 0;
		
		for(int i = 0; i < entradas.length; i++ ) {
			
			elementosVetor[i] = Integer.parseInt(entradas[i]);
			total += elementosVetor[i];
		}
		
		System.out.println("A soma do vetor é: " + total);
	}
	
	private static void verificarMaiorMenor(String[] entradas) {
		
		System.out.println("###### Verificar Maior e Menor ######");
		
		int elementosVetor[] = new int[entradas.length];
		
		int maior = Integer.MIN_VALUE;
		
		int menor = Integer.MAX_VALUE;
		
		for(int i = 0; i < entradas.length; i++) {
			
			elementosVetor[i] = Integer.parseInt(entradas[i]);
			
			if(elementosVetor[i] > maior) {
				maior = elementosVetor[i];
			}
			if(elementosVetor[i] < menor) {
				menor = elementosVetor[i];
			}
		}
		
		System.out.println("O valor maior do vetor é: " + maior + " e o valor menor é: " + menor);
		
	}
	
	private static void calcularMedia(String[] entradas) {
		
		System.out.println("###### Calcular média ######");
		
		int elementosVetor[] = new int[entradas.length];
		
		int total = 0;
		
		for(int i = 0; i < entradas.length; i++) {
			elementosVetor[i] = Integer.parseInt(entradas[i]);
			total += elementosVetor[i];
		}
		
		double media = total / entradas.length;
		
		System.out.println("A média dos valores do vetor é: " + media);
		
	}
	
	private static void inverterElementoVetor(String[] entradas) {
		
		System.out.println("###### Inverter elementos do vetor ######");
		
		for(int i =0; i < entradas.length; i++) {
			System.out.println(entradas[i]);
		}
		
		for(int i = entradas.length - 1; i >= 0; i--) {
			System.out.println(entradas[i]);
		}
	
	}
	
	private static void verificarParImpar(String[] entradas) {
		
		System.out.println("###### Verificar par o impar ######");
		
		int elementosVetor[] = new int[entradas.length];
		
		int par = 0;
		
		int impar = 0;
		
		for(int i = 0; i < entradas.length; i++) {
			elementosVetor[i] = Integer.parseInt(entradas[i]);
			
			if(elementosVetor[i] %2 == 0) {
				par++;
			} else {
				impar++;
			}
		}
		System.out.println("A quantidade de números pares é: " + par + " e a quantidade de impares é: " + impar);
	}
}
