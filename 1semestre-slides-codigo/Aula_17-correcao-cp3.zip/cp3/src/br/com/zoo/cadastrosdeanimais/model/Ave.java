package br.com.zoo.cadastrosdeanimais.model;

public class Ave extends Animal {
	
	private String pena;
	
	private String cor;
	
	public Ave(String nome, int idade, String pena, String cor) {
		this.pena = pena;
		this.cor = cor;
		this.nome = nome;
		this.idade = idade;
	}

	public String getPena() {
		return pena;
	}

	public void setPena(String pena) {
		this.pena = pena;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public void voar() {
		System.out.println("A ave voa!");
	}
	
	public void comerGrao() {
		System.out.println("Comer grão!");
	}

	@Override
	public void fazerAniversario(int ano) {
		setIdade(this.getIdade() + ano);
		
		System.out.println("A idade do animal é: " + getIdade());
		
	}
	
	@Override
	public void imprimir() {
		System.out.println( "Descrição da ave: nome -> " + this.nome + " idade -> " + this.idade + " pena ->" + this.pena + " cor ->" + this.cor);
		
	}

}
