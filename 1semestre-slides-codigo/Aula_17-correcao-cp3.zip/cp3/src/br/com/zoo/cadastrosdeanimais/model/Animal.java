package br.com.zoo.cadastrosdeanimais.model;

public abstract class Animal {
	
	protected int idade;
	
	protected String nome;
	
    public abstract void fazerAniversario(int ano);
    
    public abstract void imprimir();

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
