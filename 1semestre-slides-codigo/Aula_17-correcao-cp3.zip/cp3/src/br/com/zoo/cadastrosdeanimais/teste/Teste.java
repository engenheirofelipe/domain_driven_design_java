package br.com.zoo.cadastrosdeanimais.teste;

import br.com.zoo.cadastrosdeanimais.model.Animal;
import br.com.zoo.cadastrosdeanimais.model.Ave;
import br.com.zoo.cadastrosdeanimais.model.Mamifero;

public class Teste {
	
	public static void main(String[] args) {
		
		/*
		 * Preenchimento do vetor de animais com aves e mamiferos
		 */
		Animal[] animais = new Animal[5];
		
		Ave ave = new Ave("pardal", 1, "curta", "marrom");
		Ave ave1 = new Ave("tucano", 2, "curta", "preto");
		Ave ave2 = new Ave("arara", 2, "longa", "azul");
		
		Mamifero mamifero = new Mamifero("gato", 3, "curto", true);
		Mamifero mamifero1 = new Mamifero("cachorro", 4, "longo", true);
		
		animais[0] = ave;
		animais[1] = ave1;
		animais[2] = ave2;
		animais[3] = mamifero;
		animais[4] = mamifero1;
		
		
		for(int i = 0; i < animais.length; i++) {
			animais[i].imprimir();
		}
		
		for(int i = 0; i < 10; i++) {
			mamifero1.fazerAniversario(1);
		}
		
	}

}
