package br.com.zoo.cadastrosdeanimais.model;

public class Mamifero extends Animal {
	
	private String pelo;
	
	private boolean mamarias;
	
	
	
	public Mamifero(String nome, int idade, String pelo, boolean mamarias) {
		this.pelo = pelo;
		this.mamarias = mamarias;
		this.nome = nome;
		this.idade = idade;
	}

	/**
	 * Esse método trata sobre o mamifero berber leite
	 */
	public void berberLeite() {
		System.out.println("O mamífero bebe leite.");
		
	}
	
	/**
	 * Brincar
	 */
	public void brincar() {
		System.out.println("O mamífero brinca.");
	}

	/**
	 * Obter pelo
	 * @return pelo
	 */
	public String getPelo() {
		return pelo;
	}

	/**
	 * Atualiza pelo
	 * @param pelo para atualizar
	 */
	public void setPelo(String pelo) {
		this.pelo = pelo;
	}

	/**
	 * Obter mamamrias
	 * @return mamaria
	 */
	public boolean getMamarias() {
		return mamarias;
	}

	/**
	 * Atualizar mamaria
	 * @param mamarias
	 */
	public void setMamarias(boolean mamarias) {
		this.mamarias = mamarias;
	}

	@Override
	public void fazerAniversario(int ano) {
		
		// Incremento do ano na idade
		setIdade(this.getIdade() + ano);
		
		System.out.println("A idade do animal é: " + getIdade());
	}
	
	@Override
	public void imprimir() {
		System.out.println( "Descrição do mafífero: nome -> " + this.nome + " idade -> " + this.idade + " pelo ->" + this.pelo + " mamarias ->" + this.mamarias);
		
	}

}
