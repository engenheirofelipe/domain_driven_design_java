package aula7;

public class TestePessoa {
	
	public static void main(String[] args) {
		
		Pessoa pessoa = new Pessoa(19, "Teste");
		pessoa.imprimir(false);
	}

}
