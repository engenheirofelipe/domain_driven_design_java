package br.com.fiap.listadepresenca.model;

public class Aluno extends Pessoa {
	
	private String rm;
	
	private String curso;
	
	public Aluno(String nome, short idade, char sexo, String rm, String curso) {
		this.rm = rm;
		this.curso = curso;
		this.nome = nome;
		this.idade = idade;
		this.sexo = sexo;
	}

	public String getRm() {
		return rm;
	}

	public void setRm(String rm) {
		this.rm = rm;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	@Override
	public void cadastrar() {
		System.out.println(" O aluno " + this.nome + " do rm " + this.rm + " é do curso " + this.curso 
				+ " tem a idade " + this.idade + " e é do sexo " + this.sexo +".");
		
	}

	@Override
	public void registrarPresenca() {
		System.out.println("Registro de presença do aluno " + this.nome + " efetuado com sucesso.");
		
	}

}
