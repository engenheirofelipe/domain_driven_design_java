package br.com.fiap.listadepresenca.model;

public abstract class Pessoa {
	
	protected String nome;
	
	protected short idade;
	
	protected char sexo;
	
	public abstract void cadastrar();
	
	public abstract void registrarPresenca();
	

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public short getIdade() {
		return idade;
	}

	public void setIdade(short idade) {
		this.idade = idade;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}
	
	

}
