package br.com.fiap.listadepresenca.teste;

import java.io.IOException;
import java.util.Scanner;

import br.com.fiap.listadepresenca.model.Aluno;
import br.com.fiap.listadepresenca.model.Professor;

public class Teste {

	public static void main(String[] args) throws IOException{
		Scanner entrada = new Scanner(System.in);
		
		System.out.println("Digite o nome do aluno");
		String nome = entrada.next();
		
		System.out.println("Digite a idade do aluno");
		short idade = entrada.nextShort();
		
		System.out.println("Digite o sexo do aluno");
		char sexo = entrada.next().charAt(0);
		
		System.out.println("Digite o rm do aluno");
		String rm = entrada.next();
		
		System.out.println("Digite o curso do aluno");
		String curso = entrada.next();
		
		Aluno aluno = new Aluno(nome,idade, sexo,rm, curso);
		aluno.cadastrar();
		
		aluno.registrarPresenca();
		
		System.out.println("########     #########");
		
		
		Professor professor = new Professor();
		
		System.out.println("Digite o nome do professor");
		professor.setNome(entrada.next());
		
		System.out.println("Digite a idade do professor");
		professor.setIdade(entrada.nextShort());
		
		System.out.println("Digite o sexo do professor");
		professor.setSexo(entrada.next().charAt(0));
		
		System.out.println("Digite o inscrição do professor");
		professor.setInscricao(entrada.next());
		
		System.out.println("Digite o disciplina do professor");
		professor.setDisciplina(entrada.next());
		
		professor.cadastrar();
		professor.registrarPresenca();
		
		entrada.close();
		
		
	}

}
