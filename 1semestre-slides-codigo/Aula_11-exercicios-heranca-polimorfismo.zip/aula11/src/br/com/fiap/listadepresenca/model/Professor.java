package br.com.fiap.listadepresenca.model;

public class Professor extends Pessoa {
	
	private String inscricao;
	
	private String disciplina;
	
	public Professor() {
	}

	public Professor(String inscricao, String disciplina) {
		this.inscricao = inscricao;
		this.disciplina = disciplina;
	}

	public String getInscricao() {
		return inscricao;
	}

	public void setInscricao(String inscricao) {
		this.inscricao = inscricao;
	}

	public String getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}

	

	@Override
	public void registrarPresenca() {
		System.out.println("Registro de presença do professor " + this.nome + " efetuado com sucesso.");
	}

	@Override
	public void cadastrar() {
		System.out.println(" O professor " + this.nome + " do inscricao " + this.inscricao + " é da disciplina " + this.disciplina 
				+ " tem a idade " + this.idade + " e é do sexo " + this.sexo +".");
		
	}

}
