package aula1;

public class Mesa {
	
	String cor;
	String material;
	short largura;
	short altura;
	short comprimento;
	
	void apoiar() {
		System.out.println("A cor " + cor);
	}
	
	void calcularArea() {
		//return largura * comprimento;
	}

}
