package aula1;

public class Aluno {
	
	String nome;
	short idade;
	String genero;
	String matricula;
	
	
	void estudar() {
		System.out.println("O aluno " + nome + " da idade " + idade + " e genero " + genero + " da matricula " + matricula + " está estudando.");
	}
	
	void comer(String comida) {
		System.out.println("Aluno comendo " + comida);
	}
	
	void imprimirAlunoFormatado() {
		System.out.printf("O aluno %s da idade %d e genero %s da matricula %s está estudando. %n", nome, idade, genero, matricula);
	}
	
	void imprimir(String...parametros) {
		// método com entrada de vários parametros
	}
}
