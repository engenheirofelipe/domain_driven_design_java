package sistema;

public class Biblioteca {
	
	private Livro[] livros;
	
	
	public void adicionarLivro() {
		
		
	}
	
	public void rastrearLivro() {
		
		
	}
	
	public void verificarDisponibilidade() {
		
		
	}

	public Livro[] getLivros() {
		return livros;
	}

	public void setLivros(Livro[] livros) {
		this.livros = livros;
	}
	
	

}
