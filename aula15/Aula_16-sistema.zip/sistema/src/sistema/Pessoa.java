package sistema;

public class Pessoa {
	
	private String nome;
	
	private int numIdentificacao;
	
	public void registrarPessoa() {
		
		
	}

}
