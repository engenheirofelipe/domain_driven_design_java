package sistema;

public class Usuario extends Pessoa {
	
	private Livro[] livros;
	
	public void pegarEmprestado() {
		
		
	}
	
	public void manterControleEmprestimo() {
		
		
	}

	public Livro[] getLivros() {
		return livros;
	}

	public void setLivros(Livro[] livros) {
		this.livros = livros;
	}

}
