package br.com.ancora.app.teste;

import java.time.LocalDate;
import java.util.Scanner;

import br.com.ancora.app.model.Loja;
import br.com.ancora.app.model.Mecanico;
import br.com.ancora.app.model.PagamentoCliente;
import br.com.ancora.app.model.PedidoCliente;
import br.com.ancora.app.model.Produto;
import br.com.ancora.app.model.VendaLoja;
import br.com.ancora.app.model.VendedorDaLoja;

public class Teste {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		
		Mecanico mecanico = new Mecanico(1, "07AB4", "teixeira@gmail.com", "produto");
		mecanico.setNome(" Mário Teixeira Romero ");
		mecanico.setEmail(" marioteixeira@gmail.com");
		mecanico.setTelefone("12 55948857");
		mecanico.setCpf("234-534-645-76");
		mecanico.setEndereco(" Rua Dom Perigom 3465");
		
		mecanico.criarCadastro();
		mecanico.fazerLogin();
		mecanico.atualizarPerfil();
		
		System.out.println(" Faça a pesquisa aqui...");
		mecanico.produtoPesquisa = scanner.next();
		
		mecanico.fazerPesquisa();
		mecanico.adicionarProdutoAoCarrinho();
		mecanico.solicitarCotacaoProduto();
		mecanico.comprarProduto();
				
		VendedorDaLoja vendedor = new VendedorDaLoja(1, LocalDate.of(2023, 9, 10), 3.543);
		vendedor.setNome(" José Jeferson Ramos ");
		vendedor.setEmail(" jose@gmail.com");
		vendedor.setTelefone("13 54654565");
		vendedor.setCpf("434-534-325-46");
		vendedor.setEndereco(" Rua Augusta 4354");
		
		vendedor.criarCadastro();
		vendedor.fazerLogin();
		vendedor.processarPedido();
		
		
		
		Produto produto = new Produto(1, "mola", 123.50, "H&R", 10, " Mola com rigidez "," Mola com rigidez e altura", " aplicação");
		produto.setDescricao(" Mola com rigidez e altura");
		vendedor.atualizarInformacoesProduto(produto, " Mola adequada para uma ampla gama de aplicações, incluindo automotivas",  
				" Mola  Adequada para uma ampla gama de aplicações, incluindo automotivas.  Feita de aço inoxidável, resistente à corrosão e ao desgaste ");
		
		
		Loja loja = new Loja();
		loja.setCnpj(" 423-654-534-65");
		loja.setEmail("bemtevi@gmail.com");
		
		loja.receberConfirmacaoCompra();
		loja.gerenciarPedido();
		
		PedidoCliente pedidocliente = new PedidoCliente(1, " Rua Manoel Bandeira 432", 240.50);
		pedidocliente.gerarTransacao();
		pedidocliente.calcularTotal();
		pedidocliente.confirmarPedido();
		pedidocliente.atualizarStatus();
		pedidocliente.cancelarPedido();
		
		PagamentoCliente pagamento = new PagamentoCliente(1, "Cartão de crédito", 250.50);
		pagamento.gerarTransacao();
		pagamento.calcularTotal();
		pagamento.validarDadosPagamento();
		pagamento.atualizarStatus();
		pagamento.gerarComprovantePagamento();
		pagamento.visualizarDetalhes();
		
		
		VendaLoja venda = new VendaLoja(1, 250.50, LocalDate.of(2023, 5, 15), " Detalhes : Venda paga no crédito , com desconto . À vista ");
		venda.gerarTransacao();
		venda.processarVenda();
		venda.calcularTotal();
		venda.aplicarDesconto();
		venda.atualizarStatus();
		venda.visualizarDetalhes();
		
		
		scanner.close();
		
		

	}

}
