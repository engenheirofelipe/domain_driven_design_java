package br.com.ancora.app.model;

import java.time.LocalDate;


public class VendaLoja extends Transacao {
	
	private int idVenda;
	
	private Double valorVenda;
	
	private LocalDate data;
	
	private String detalhesVenda;
	
	

	public VendaLoja() {
		super();
	}

	public VendaLoja(int idVenda, Double valorVenda, LocalDate data, String detalhesVenda) {
		super();
		this.idVenda = idVenda;
		this.valorVenda = valorVenda;
		this.data = data;
		this.detalhesVenda = detalhesVenda;
	}

	public int getIdVenda() {
		return idVenda;
	}

	public void setIdVenda(int idVenda) {
		this.idVenda = idVenda;
	}

	public Double getValorVenda() {
		return valorVenda;
	}

	public void setValorVenda(Double valorVenda) {
		this.valorVenda = valorVenda;
	}

	public LocalDate getData() {
		return data;
	}

	public void setData(LocalDate data) {
		this.data = data;
	}

	public String getDetalhesVenda() {
		return detalhesVenda;
	}

	public void setDetalhesVenda(String detalhesVenda) {
		this.detalhesVenda = detalhesVenda;
	}
	
	@Override
	public void gerarTransacao() {
		
		System.out.println(" A venda com o id " + idVenda + " com o valor de  " + valorTotal + " foi gerada com sucesso !");
		
	}

	
	@Override
	public void visualizarDetalhes() {
		
		System.out.println(" O vendedor visualizou os detalhes da venda : " + detalhesVenda);
		
	}
	
	@Override
	public void calcularTotal() {
		
		System.out.println(" O valor da venda foi calculado");
		
	}

	@Override
	public void atualizarStatus() {
	
		System.out.println(" A venda  está atualizada");
		
	}
	
	public void processarVenda() {
		
		System.out.println(" A venda foi processada !");
		
	}

	public void aplicarDesconto() {
		
		System.out.println(" A venda  possui desconto de 10%");
		
	}
	
	
	
}
