package br.com.ancora.app.model;

public class Loja {
	
	private int idLoja;
	
	private String nomeLoja;
	
	private String cnpj;
	
	private String telefone;
	
	private String email;
	
	

	public Loja() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Loja(int idLoja, String nomeLoja, String cnpj, String telefone, String email) {
		super();
		this.idLoja = idLoja;
		this.nomeLoja = nomeLoja;
		this.cnpj = cnpj;
		this.telefone = telefone;
		this.email = email;
	}

	public int getIdLoja() {
		return idLoja;
	}

	public void setIdLoja(int idLoja) {
		this.idLoja = idLoja;
	}

	public String getNomeLoja() {
		return nomeLoja;
	}

	public void setNomeLoja(String nomeLoja) {
		this.nomeLoja = nomeLoja;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public void gerenciarPedido() {
		
		System.out.println(" A loja que possui o email : " + getEmail() + " e cnpj : " + getCnpj() + " está com o pedido separado");
		
	};
	
	public void receberConfirmacaoCompra() {
		
		System.out.println(" A loja que possui o email : " + getEmail() + " e cnpj : " + getCnpj() + " recebeu a confirmação de compra");
		
	};
	
	
	

}
