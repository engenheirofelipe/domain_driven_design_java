package br.com.ancora.app.model;

public class Categoria {

}
