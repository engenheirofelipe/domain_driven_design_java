package br.com.ancora.app.model;

public class PagamentoCliente extends Transacao {

	private int idPagamento;
	
	private String metodo;
	
	

	public PagamentoCliente() {
		super();
	}

	public PagamentoCliente(int idPagamento, String metodo,  Double valorTotal) {
		super();
		this.idPagamento = idPagamento;
		this.metodo = metodo;
		this.valorTotal = valorTotal;
	}

	public int getIdPagamento() {
		return idPagamento;
	}

	public void setIdPagamento(int idPagamento) {
		this.idPagamento = idPagamento;
	}

	public String getMetodo() {
		return metodo;
	}

	public void setMetodo(String metodo) {
		this.metodo = metodo;
	}
	

	@Override
	public void gerarTransacao() {
		
		System.out.println(" O pagamento com o id " + idPagamento + " foi gerado com sucesso !");
		
	}

	
	@Override
	public void visualizarDetalhes() {
		
		System.out.println(" O mecânico visualizou detalhes do pagamento");
		
	}
	
	@Override
	public void calcularTotal() {
		
		System.out.println(" O valor total " + valorTotal + " do pagamento foi calculado");
		
	}

	@Override
	public void atualizarStatus() {
	
		System.out.println(" O pagamento está atualizado");
		
	}

	
	public void validarDadosPagamento() {
		
		System.out.println(" Os dados do pagamento foram validados o cliente pagou com o método : " + metodo);
		
	}
	

	public void gerarComprovantePagamento() {
		
		System.out.println(" O comprovante da venda com id : " + idPagamento + " foi gerado ");
		
	}
	
	
}
