package br.com.ancora.app.model;

public class PedidoCliente extends Transacao {

	private int idPedido;
	
	private String enderecoEntrega;
	
	

	public PedidoCliente() {
		super();
	}

	public PedidoCliente(int idPedido, String enderecoEntrega, Double valorTotal) {
		super();
		this.idPedido = idPedido;
		this.enderecoEntrega = enderecoEntrega;
		this.valorTotal = valorTotal;
	}
	
	public int getIdPedido() {
		return idPedido;
	}

	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}

	public String getEnderecoEntrega() {
		return enderecoEntrega;
	}

	public void setEnderecoEntrega(String enderecoEntrega) {
		this.enderecoEntrega = enderecoEntrega;
	}
	
	public Double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(Double  valorTotal) {
		this. valorTotal =  valorTotal;
	}

	@Override
	public void gerarTransacao() {
		
		System.out.println(" O pedido do cliente com id : " + idPedido + " com o endereço " + enderecoEntrega + " foi gerado com sucesso !");
		
	}

	
	
	@Override
	public void visualizarDetalhes() {
		
		System.out.println(" O pedido com o id " + idPedido + " foi visualizado");
		
	}
	
	@Override
	public void calcularTotal() {
		
		System.out.println(" O pedido com o valor de " + valorTotal + " foi calculado");
		
	}

	@Override
	public void atualizarStatus() {
	
		System.out.println(" O pedido está atualizado");
		
	}
	
	public void confirmarPedido() {
		
		System.out.println(" O pedido com o id " + idPedido + " foi confirmado com sucesso !");
	}

	public void cancelarPedido() {
		
		System.out.println(" O pedido não foi cancelado");
		
	}
	
	
	
}
