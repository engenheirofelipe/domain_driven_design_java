package br.com.ancora.app.model;

import java.util.Date;

public abstract class Transacao {

	protected int idTransacao;
	
	protected Date dataTransacao;
	
	protected String statusTransacao;
	
	protected Double valorTotal; 
	
	protected String informacoes;
	
	

	public Transacao() {
		super();
	}

	public Transacao(int idTransacao, Date dataTransacao, String statusTransacao, Double valorTotal,
			String informacoes) {
		super();
		this.idTransacao = idTransacao;
		this.dataTransacao = dataTransacao;
		this.statusTransacao = statusTransacao;
		this.valorTotal = valorTotal;
		this.informacoes = informacoes;
	}

	public int getIdTransacao() {
		return idTransacao;
	}

	public void setIdTransacao(int idTransacao) {
		this.idTransacao = idTransacao;
	}

	public Date getDataTransacao() {
		return dataTransacao;
	}

	public void setDataTransacao(Date dataTransacao) {
		this.dataTransacao = dataTransacao;
	}

	public String getStatusTransacao() {
		return statusTransacao;
	}

	public void setStatusTransacao(String statusTransacao) {
		this.statusTransacao = statusTransacao;
	}

	public Double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(Double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getInformacoes() {
		return informacoes;
	}

	public void setInformacoes(String informacoes) {
		this.informacoes = informacoes;
	}
	
	public abstract void gerarTransacao();
	
	public abstract void visualizarDetalhes();
	
	public abstract void calcularTotal();
	
	public abstract void atualizarStatus();
		
	
	
	
}
